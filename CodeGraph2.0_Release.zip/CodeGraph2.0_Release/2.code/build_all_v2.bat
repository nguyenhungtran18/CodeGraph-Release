@echo off
echo ==========================================
echo CodeGraph v2.0 - TokenVector Build Script
echo Zero-Trust Static Linking Architecture
echo ==========================================

cd /d "%~dp0"

echo [1/7] Bien dich master_key_manager.exe...
tools\pytok.exe master_key_manager.tkv master_key_manager.exe

echo [2/7] Bien dich codegraph_v2.exe (Orchestrator)...
tools\pytok.exe codegraph_v2.tkv codegraph_v2.exe

echo [3/7] Bien dich CodeGraph_MCP.exe (AI Assistant Server)...
tools\pytok.exe CodeGraph_MCP.tkv CodeGraph_MCP.exe

echo [4/7] Bien dich visualize_graph.exe (Graph Visualizer Engine)...
tools\pytok.exe extensions\visualize_graph.tkv tools\visualize_graph.exe

echo [5/7] Bien dich gen_def_summaries.exe...
tools\pytok.exe gen_def_summaries.tkv gen_def_summaries.exe

echo [6/7] Bien dich gen_node_summaries.exe...
tools\pytok.exe gen_node_summaries.tkv gen_node_summaries.exe

echo [7/7] Bien dich build_fast_mcp.exe...
tools\pytok.exe build_fast_mcp.tkv build_fast_mcp.exe

echo ==========================================
echo HOAN TAT! Tat ca cac file .tkv da duoc bien dich thanh cong!
echo ==========================================
