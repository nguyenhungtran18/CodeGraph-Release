@echo off
title CodeGraph v2.0 Orchestrator Launcher
cd /d "%~dp0"
echo ==================================================
echo   CODEGRAPH v2.0 - TOKENVECTOR ORCHESTRATOR
echo ==================================================
echo.
tools\pytok.exe codegraph_v2.tkv --name CodeGraph --path .
echo.
echo ==================================================
echo Đã hoàn tất! Mở file GraphView\graph_visualization.html để xem đồ thị.
echo ==================================================
pause
