# CodeGraph v2.0.0 - Professional Software Architecture & Graph Engine

CodeGraph v2.0.0 là hệ thống phân tích kiến trúc mã nguồn và trực quan hóa đồ thị liên kết 3D dành cho AI Assistant (Cursor, Windsurf, Antigravity, VSCode) dựa trên ngôn ngữ TokenVector (.tkv) siêu tốc.

---

## 📂 Cấu trúc Bản Phát hành (Release Structure)

Bản phát hành chuẩn hóa v2.0.0 được phân loại tập trung theo các thư mục:

- `CodeGraph_v2_Launcher.bat`: Tập lệnh kích hoạt 1-Click khởi chạy toàn bộ hệ thống trên Windows.
- `1.UI/`: Chứa gói giao diện đồ thị HTML tương tác 3D (`GraphView/graph_visualization.html` và `GraphView/codegraph_data.js`).
- `2.code/`: Mã nguồn TokenVector (`.tkv`), file nhị phân đã biên dịch (`.exe`), công cụ phân tích tĩnh (`tools/`) và extension (`extensions/`).

---

## 🚀 Hướng dẫn Cài đặt & Vận hành

### 1. Khởi chạy trực tiếp (Windows 1-Click)
1. Click đúp trực tiếp vào tệp **`CodeGraph_v2_Launcher.bat`**.
2. Hệ thống sẽ tự động quét mã nguồn, xác thực bản quyền và tạo gói giao diện tại `2.UI/GraphView/graph_visualization.html`.

### 2. Tích hợp MCP Server vào VSCode / AI Editor
Thêm đoạn cấu hình sau vào file `mcp_config.json`:

```json
{
  "mcpServers": {
    "CodeGraph": {
      "command": "3.code/CodeGraph_MCP.exe"
    }
  }
}
```

---

## 🔑 Quản lý Bản quyền (Licensing)
- **Lemon Squeezy API:** Tự động xác thực key thương mại mua trực tuyến.
- **Offline Master Key Bypass:** Nhập mã Master Key (Hạn sử dụng: 2099-12-31).

---
© 2026 CodeGraph Team. All Rights Reserved.
