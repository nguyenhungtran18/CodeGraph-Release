window.CodeGraphData = {
  nodes: [
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:create_shortcut",
    "name": "pywin32_postinstall.py:create_shortcut",
    "type": "file",
    "community": "pywin32_postinstall.py:create_shortcut",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:create_shortcut",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:gen_node_summaries.py:save",
    "name": "gen_node_summaries.py:save",
    "type": "file",
    "community": "gen_node_summaries.py:save",
    "color": "#3b82f6",
    "source_path": "function:gen_node_summaries.py:save",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:gen_def_summaries.py:build_prompt",
    "name": "gen_def_summaries.py:build_prompt",
    "type": "file",
    "community": "gen_def_summaries.py:build_prompt",
    "color": "#3b82f6",
    "source_path": "function:gen_def_summaries.py:build_prompt",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_app.py:CodeGraphEngine.scan_project",
    "name": "codegraph_app.py:CodeGraphEngine.scan_project",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphEngine.scan_project",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:CodeGraphEngine.scan_project",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:get_special_folder_path",
    "name": "pywin32_postinstall.py:get_special_folder_path",
    "type": "file",
    "community": "pywin32_postinstall.py:get_special_folder_path",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:get_special_folder_path",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_app.py:CodeGraphRequestHandler._send_html",
    "name": "codegraph_app.py:CodeGraphRequestHandler._send_html",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphRequestHandler._send_html",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:CodeGraphRequestHandler._send_html",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:write",
    "name": "pywin32_postinstall.py:write",
    "type": "file",
    "community": "pywin32_postinstall.py:write",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:write",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "class:codegraph_app.py:CodeGraphEngine",
    "name": "codegraph_app.py:CodeGraphEngine",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphEngine",
    "color": "#3b82f6",
    "source_path": "class:codegraph_app.py:CodeGraphEngine",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:extensions/dynamic_call_scanner.py:run_dynamic_scan",
    "name": "dynamic_call_scanner.py:run_dynamic_scan",
    "type": "file",
    "community": "dynamic_call_scanner.py:run_dynamic_scan",
    "color": "#3b82f6",
    "source_path": "function:extensions/dynamic_call_scanner.py:run_dynamic_scan",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_app.py:CodeGraphRequestHandler.do_POST",
    "name": "codegraph_app.py:CodeGraphRequestHandler.do_POST",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphRequestHandler.do_POST",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:CodeGraphRequestHandler.do_POST",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_Name",
    "name": "dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_Name",
    "type": "file",
    "community": "dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_Name",
    "color": "#3b82f6",
    "source_path": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_Name",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:codegraph_app.py:get_graph_html_template",
    "name": "codegraph_app.py:get_graph_html_template",
    "type": "file",
    "community": "codegraph_app.py:get_graph_html_template",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:get_graph_html_template",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_app.py:CodeGraphRequestHandler.do_GET",
    "name": "codegraph_app.py:CodeGraphRequestHandler.do_GET",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphRequestHandler.do_GET",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:CodeGraphRequestHandler.do_GET",
    "degree": 4,
    "neighbors": [],
    "group": 1,
    "val": 4
  },
  {
    "id": "function:build_fast_mcp.py:run_cmd",
    "name": "build_fast_mcp.py:run_cmd",
    "type": "file",
    "community": "build_fast_mcp.py:run_cmd",
    "color": "#3b82f6",
    "source_path": "function:build_fast_mcp.py:run_cmd",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_app.py:CodeGraphEngine.get_ctxpack",
    "name": "codegraph_app.py:CodeGraphEngine.get_ctxpack",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphEngine.get_ctxpack",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:CodeGraphEngine.get_ctxpack",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "class:codegraph_mcp.py:CodeGraphEngine",
    "name": "codegraph_mcp.py:CodeGraphEngine",
    "type": "file",
    "community": "codegraph_mcp.py:CodeGraphEngine",
    "color": "#3b82f6",
    "source_path": "class:codegraph_mcp.py:CodeGraphEngine",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:extensions/visualize_graph.py:generate_visualization",
    "name": "visualize_graph.py:generate_visualization",
    "type": "file",
    "community": "visualize_graph.py:generate_visualization",
    "color": "#3b82f6",
    "source_path": "function:extensions/visualize_graph.py:generate_visualization",
    "degree": 4,
    "neighbors": [],
    "group": 1,
    "val": 4
  },
  {
    "id": "function:codegraph_app.py:main",
    "name": "codegraph_app.py:main",
    "type": "file",
    "community": "codegraph_app.py:main",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:main",
    "degree": 4,
    "neighbors": [],
    "group": 1,
    "val": 4
  },
  {
    "id": "file:codegraph_mcp.py",
    "name": "codegraph_mcp.py",
    "type": "file",
    "community": "codegraph_mcp.py",
    "color": "#3b82f6",
    "source_path": "file:codegraph_mcp.py",
    "degree": 10,
    "neighbors": [],
    "group": 1,
    "val": 10
  },
  {
    "id": "function:gen_def_summaries.py:load_defs",
    "name": "gen_def_summaries.py:load_defs",
    "type": "file",
    "community": "gen_def_summaries.py:load_defs",
    "color": "#3b82f6",
    "source_path": "function:gen_def_summaries.py:load_defs",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_mcp.py:get_code_graph",
    "name": "codegraph_mcp.py:get_code_graph",
    "type": "file",
    "community": "codegraph_mcp.py:get_code_graph",
    "color": "#3b82f6",
    "source_path": "function:codegraph_mcp.py:get_code_graph",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:gen_node_summaries.py:build_prompt",
    "name": "gen_node_summaries.py:build_prompt",
    "type": "file",
    "community": "gen_node_summaries.py:build_prompt",
    "color": "#3b82f6",
    "source_path": "function:gen_node_summaries.py:build_prompt",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_FunctionDef",
    "name": "dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_FunctionDef",
    "type": "file",
    "community": "dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_FunctionDef",
    "color": "#3b82f6",
    "source_path": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_FunctionDef",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "file:extensions/treesitter_parser.py",
    "name": "treesitter_parser.py",
    "type": "file",
    "community": "treesitter_parser.py",
    "color": "#3b82f6",
    "source_path": "file:extensions/treesitter_parser.py",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "function:codegraph_mcp.py:analyze_impact",
    "name": "codegraph_mcp.py:analyze_impact",
    "type": "file",
    "community": "codegraph_mcp.py:analyze_impact",
    "color": "#3b82f6",
    "source_path": "function:codegraph_mcp.py:analyze_impact",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_mcp.py:get_graph_stats",
    "name": "codegraph_mcp.py:get_graph_stats",
    "type": "file",
    "community": "codegraph_mcp.py:get_graph_stats",
    "color": "#3b82f6",
    "source_path": "function:codegraph_mcp.py:get_graph_stats",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.__init__",
    "name": "dynamic_call_scanner.py:UnappliedSymbolVisitor.__init__",
    "type": "file",
    "community": "dynamic_call_scanner.py:UnappliedSymbolVisitor.__init__",
    "color": "#3b82f6",
    "source_path": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.__init__",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:codegraph_app.py:find_free_port",
    "name": "codegraph_app.py:find_free_port",
    "type": "file",
    "community": "codegraph_app.py:find_free_port",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:find_free_port",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_app.py:CodeGraphEngine.get_impact",
    "name": "codegraph_app.py:CodeGraphEngine.get_impact",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphEngine.get_impact",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:CodeGraphEngine.get_impact",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_Assign",
    "name": "dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_Assign",
    "type": "file",
    "community": "dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_Assign",
    "color": "#3b82f6",
    "source_path": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_Assign",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "file:build_fast_mcp.py",
    "name": "build_fast_mcp.py",
    "type": "file",
    "community": "build_fast_mcp.py",
    "color": "#3b82f6",
    "source_path": "file:build_fast_mcp.py",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:gen_def_summaries.py:save",
    "name": "gen_def_summaries.py:save",
    "type": "file",
    "community": "gen_def_summaries.py:save",
    "color": "#3b82f6",
    "source_path": "function:gen_def_summaries.py:save",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:gen_def_summaries.py:parse_reply",
    "name": "gen_def_summaries.py:parse_reply",
    "type": "file",
    "community": "gen_def_summaries.py:parse_reply",
    "color": "#3b82f6",
    "source_path": "function:gen_def_summaries.py:parse_reply",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:UnsetPyKeyVal",
    "name": "pywin32_postinstall.py:UnsetPyKeyVal",
    "type": "file",
    "community": "pywin32_postinstall.py:UnsetPyKeyVal",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:UnsetPyKeyVal",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "name": "pywin32_postinstall.py",
    "type": "file",
    "community": "pywin32_postinstall.py",
    "color": "#3b82f6",
    "source_path": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "degree": 21,
    "neighbors": [],
    "group": 1,
    "val": 21
  },
  {
    "id": "function:extensions/visualize_graph.py:extract_community_name",
    "name": "visualize_graph.py:extract_community_name",
    "type": "file",
    "community": "visualize_graph.py:extract_community_name",
    "color": "#3b82f6",
    "source_path": "function:extensions/visualize_graph.py:extract_community_name",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "file:codegraph_app.py",
    "name": "codegraph_app.py",
    "type": "file",
    "community": "codegraph_app.py",
    "color": "#3b82f6",
    "source_path": "file:codegraph_app.py",
    "degree": 14,
    "neighbors": [],
    "group": 1,
    "val": 14
  },
  {
    "id": "class:codegraph_app.py:CodeGraphRequestHandler",
    "name": "codegraph_app.py:CodeGraphRequestHandler",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphRequestHandler",
    "color": "#3b82f6",
    "source_path": "class:codegraph_app.py:CodeGraphRequestHandler",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:get_system_dir",
    "name": "pywin32_postinstall.py:get_system_dir",
    "type": "file",
    "community": "pywin32_postinstall.py:get_system_dir",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:get_system_dir",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:codegraph_mcp.py:pack_context",
    "name": "codegraph_mcp.py:pack_context",
    "type": "file",
    "community": "codegraph_mcp.py:pack_context",
    "color": "#3b82f6",
    "source_path": "function:codegraph_mcp.py:pack_context",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:gen_node_summaries.py:load_targets",
    "name": "gen_node_summaries.py:load_targets",
    "type": "file",
    "community": "gen_node_summaries.py:load_targets",
    "color": "#3b82f6",
    "source_path": "function:gen_node_summaries.py:load_targets",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:uninstall",
    "name": "pywin32_postinstall.py:uninstall",
    "type": "file",
    "community": "pywin32_postinstall.py:uninstall",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:uninstall",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:install",
    "name": "pywin32_postinstall.py:install",
    "type": "file",
    "community": "pywin32_postinstall.py:install",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:install",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:gen_def_summaries.py:main",
    "name": "gen_def_summaries.py:main",
    "type": "file",
    "community": "gen_def_summaries.py:main",
    "color": "#3b82f6",
    "source_path": "function:gen_def_summaries.py:main",
    "degree": 6,
    "neighbors": [],
    "group": 1,
    "val": 6
  },
  {
    "id": "function:codegraph_mcp.py:get_engine",
    "name": "codegraph_mcp.py:get_engine",
    "type": "file",
    "community": "codegraph_mcp.py:get_engine",
    "color": "#3b82f6",
    "source_path": "function:codegraph_mcp.py:get_engine",
    "degree": 6,
    "neighbors": [],
    "group": 1,
    "val": 6
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_testall.py:find_and_run",
    "name": "pywin32_testall.py:find_and_run",
    "type": "file",
    "community": "pywin32_testall.py:find_and_run",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_testall.py:find_and_run",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_mcp.py:CodeGraphEngine.scan_project",
    "name": "codegraph_mcp.py:CodeGraphEngine.scan_project",
    "type": "file",
    "community": "codegraph_mcp.py:CodeGraphEngine.scan_project",
    "color": "#3b82f6",
    "source_path": "function:codegraph_mcp.py:CodeGraphEngine.scan_project",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "class:.build_venv/Scripts/pywin32_postinstall.py:Tee",
    "name": "pywin32_postinstall.py:Tee",
    "type": "file",
    "community": "pywin32_postinstall.py:Tee",
    "color": "#3b82f6",
    "source_path": "class:.build_venv/Scripts/pywin32_postinstall.py:Tee",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:CopyTo",
    "name": "pywin32_postinstall.py:CopyTo",
    "type": "file",
    "community": "pywin32_postinstall.py:CopyTo",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:CopyTo",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterCOMObjects",
    "name": "pywin32_postinstall.py:RegisterCOMObjects",
    "type": "file",
    "community": "pywin32_postinstall.py:RegisterCOMObjects",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterCOMObjects",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "file:gen_node_summaries.py",
    "name": "gen_node_summaries.py",
    "type": "file",
    "community": "gen_node_summaries.py",
    "color": "#3b82f6",
    "source_path": "file:gen_node_summaries.py",
    "degree": 5,
    "neighbors": [],
    "group": 1,
    "val": 5
  },
  {
    "id": "function:build_fast_mcp.py:build_fast",
    "name": "build_fast_mcp.py:build_fast",
    "type": "file",
    "community": "build_fast_mcp.py:build_fast",
    "color": "#3b82f6",
    "source_path": "function:build_fast_mcp.py:build_fast",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "file:extensions/dynamic_call_scanner.py",
    "name": "dynamic_call_scanner.py",
    "type": "file",
    "community": "dynamic_call_scanner.py",
    "color": "#3b82f6",
    "source_path": "file:extensions/dynamic_call_scanner.py",
    "degree": 6,
    "neighbors": [],
    "group": 1,
    "val": 6
  },
  {
    "id": "function:gen_node_summaries.py:main",
    "name": "gen_node_summaries.py:main",
    "type": "file",
    "community": "gen_node_summaries.py:main",
    "color": "#3b82f6",
    "source_path": "function:gen_node_summaries.py:main",
    "degree": 5,
    "neighbors": [],
    "group": 1,
    "val": 5
  },
  {
    "id": "file:.build_venv/Scripts/pywin32_testall.py",
    "name": "pywin32_testall.py",
    "type": "file",
    "community": "pywin32_testall.py",
    "color": "#3b82f6",
    "source_path": "file:.build_venv/Scripts/pywin32_testall.py",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "function:codegraph_app.py:CodeGraphRequestHandler.log_message",
    "name": "codegraph_app.py:CodeGraphRequestHandler.log_message",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphRequestHandler.log_message",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:CodeGraphRequestHandler.log_message",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:extensions/treesitter_parser.py:scan_multilang_files",
    "name": "treesitter_parser.py:scan_multilang_files",
    "type": "file",
    "community": "treesitter_parser.py:scan_multilang_files",
    "color": "#3b82f6",
    "source_path": "function:extensions/treesitter_parser.py:scan_multilang_files",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "function:codegraph_app.py:CodeGraphEngine.__init__",
    "name": "codegraph_app.py:CodeGraphEngine.__init__",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphEngine.__init__",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:CodeGraphEngine.__init__",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:gen_def_summaries.py:add",
    "name": "gen_def_summaries.py:add",
    "type": "file",
    "community": "gen_def_summaries.py:add",
    "color": "#3b82f6",
    "source_path": "function:gen_def_summaries.py:add",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:main",
    "name": "pywin32_postinstall.py:main",
    "type": "file",
    "community": "pywin32_postinstall.py:main",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:main",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:extensions/visualize_graph.py:load_json",
    "name": "visualize_graph.py:load_json",
    "type": "file",
    "community": "visualize_graph.py:load_json",
    "color": "#3b82f6",
    "source_path": "function:extensions/visualize_graph.py:load_json",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "function:codegraph_mcp.py:CodeGraphEngine.get_impact",
    "name": "codegraph_mcp.py:CodeGraphEngine.get_impact",
    "type": "file",
    "community": "codegraph_mcp.py:CodeGraphEngine.get_impact",
    "color": "#3b82f6",
    "source_path": "function:codegraph_mcp.py:CodeGraphEngine.get_impact",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterHelpFile",
    "name": "pywin32_postinstall.py:RegisterHelpFile",
    "type": "file",
    "community": "pywin32_postinstall.py:RegisterHelpFile",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterHelpFile",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "function:gen_def_summaries.py:source_index",
    "name": "gen_def_summaries.py:source_index",
    "type": "file",
    "community": "gen_def_summaries.py:source_index",
    "color": "#3b82f6",
    "source_path": "function:gen_def_summaries.py:source_index",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:get_root_hkey",
    "name": "pywin32_postinstall.py:get_root_hkey",
    "type": "file",
    "community": "pywin32_postinstall.py:get_root_hkey",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:get_root_hkey",
    "degree": 4,
    "neighbors": [],
    "group": 1,
    "val": 4
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:Tee.__init__",
    "name": "pywin32_postinstall.py:Tee.__init__",
    "type": "file",
    "community": "pywin32_postinstall.py:Tee.__init__",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:Tee.__init__",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:extensions/treesitter_parser.py:traverse",
    "name": "treesitter_parser.py:traverse",
    "type": "file",
    "community": "treesitter_parser.py:traverse",
    "color": "#3b82f6",
    "source_path": "function:extensions/treesitter_parser.py:traverse",
    "degree": 4,
    "neighbors": [],
    "group": 1,
    "val": 4
  },
  {
    "id": "function:extensions/visualize_graph.py:log",
    "name": "visualize_graph.py:log",
    "type": "file",
    "community": "visualize_graph.py:log",
    "color": "#3b82f6",
    "source_path": "function:extensions/visualize_graph.py:log",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "function:codegraph_mcp.py:CodeGraphEngine.get_ctxpack",
    "name": "codegraph_mcp.py:CodeGraphEngine.get_ctxpack",
    "type": "file",
    "community": "codegraph_mcp.py:CodeGraphEngine.get_ctxpack",
    "color": "#3b82f6",
    "source_path": "function:codegraph_mcp.py:CodeGraphEngine.get_ctxpack",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:verify_destination",
    "name": "pywin32_postinstall.py:verify_destination",
    "type": "file",
    "community": "pywin32_postinstall.py:verify_destination",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:verify_destination",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_app.py:CodeGraphRequestHandler._send_json",
    "name": "codegraph_app.py:CodeGraphRequestHandler._send_json",
    "type": "file",
    "community": "codegraph_app.py:CodeGraphRequestHandler._send_json",
    "color": "#3b82f6",
    "source_path": "function:codegraph_app.py:CodeGraphRequestHandler._send_json",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "file:gen_def_summaries.py",
    "name": "gen_def_summaries.py",
    "type": "file",
    "community": "gen_def_summaries.py",
    "color": "#3b82f6",
    "source_path": "file:gen_def_summaries.py",
    "degree": 7,
    "neighbors": [],
    "group": 1,
    "val": 7
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:SetPyKeyVal",
    "name": "pywin32_postinstall.py:SetPyKeyVal",
    "type": "file",
    "community": "pywin32_postinstall.py:SetPyKeyVal",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:SetPyKeyVal",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:fixup_dbi",
    "name": "pywin32_postinstall.py:fixup_dbi",
    "type": "file",
    "community": "pywin32_postinstall.py:fixup_dbi",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:fixup_dbi",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "file:extensions/visualize_graph.py",
    "name": "visualize_graph.py",
    "type": "file",
    "community": "visualize_graph.py",
    "color": "#3b82f6",
    "source_path": "file:extensions/visualize_graph.py",
    "degree": 4,
    "neighbors": [],
    "group": 1,
    "val": 4
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_testall.py:main",
    "name": "pywin32_testall.py:main",
    "type": "file",
    "community": "pywin32_testall.py:main",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_testall.py:main",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_testall.py:run_test",
    "name": "pywin32_testall.py:run_test",
    "type": "file",
    "community": "pywin32_testall.py:run_test",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_testall.py:run_test",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:extensions/treesitter_parser.py:get_parser_for_lang",
    "name": "treesitter_parser.py:get_parser_for_lang",
    "type": "file",
    "community": "treesitter_parser.py:get_parser_for_lang",
    "color": "#3b82f6",
    "source_path": "function:extensions/treesitter_parser.py:get_parser_for_lang",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:codegraph_mcp.py:CodeGraphEngine.__init__",
    "name": "codegraph_mcp.py:CodeGraphEngine.__init__",
    "type": "file",
    "community": "codegraph_mcp.py:CodeGraphEngine.__init__",
    "color": "#3b82f6",
    "source_path": "function:codegraph_mcp.py:CodeGraphEngine.__init__",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:LoadSystemModule",
    "name": "pywin32_postinstall.py:LoadSystemModule",
    "type": "file",
    "community": "pywin32_postinstall.py:LoadSystemModule",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:LoadSystemModule",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:get_shortcuts_folder",
    "name": "pywin32_postinstall.py:get_shortcuts_folder",
    "type": "file",
    "community": "pywin32_postinstall.py:get_shortcuts_folder",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:get_shortcuts_folder",
    "degree": 3,
    "neighbors": [],
    "group": 1,
    "val": 3
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterPythonwin",
    "name": "pywin32_postinstall.py:RegisterPythonwin",
    "type": "file",
    "community": "pywin32_postinstall.py:RegisterPythonwin",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterPythonwin",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:.build_venv/Scripts/pywin32_postinstall.py:flush",
    "name": "pywin32_postinstall.py:flush",
    "type": "file",
    "community": "pywin32_postinstall.py:flush",
    "color": "#3b82f6",
    "source_path": "function:.build_venv/Scripts/pywin32_postinstall.py:flush",
    "degree": 1,
    "neighbors": [],
    "group": 1,
    "val": 1
  },
  {
    "id": "function:gen_node_summaries.py:parse_reply",
    "name": "gen_node_summaries.py:parse_reply",
    "type": "file",
    "community": "gen_node_summaries.py:parse_reply",
    "color": "#3b82f6",
    "source_path": "function:gen_node_summaries.py:parse_reply",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  },
  {
    "id": "class:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor",
    "name": "dynamic_call_scanner.py:UnappliedSymbolVisitor",
    "type": "file",
    "community": "dynamic_call_scanner.py:UnappliedSymbolVisitor",
    "color": "#3b82f6",
    "source_path": "class:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor",
    "degree": 2,
    "neighbors": [],
    "group": 1,
    "val": 2
  }
],
  links: [
  {
    "source": "file:build_fast_mcp.py",
    "target": "function:build_fast_mcp.py:run_cmd",
    "value": 1
  },
  {
    "source": "file:build_fast_mcp.py",
    "target": "function:build_fast_mcp.py:build_fast",
    "value": 1
  },
  {
    "source": "function:build_fast_mcp.py:build_fast",
    "target": "function:build_fast_mcp.py:run_cmd",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "class:codegraph_app.py:CodeGraphEngine",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:CodeGraphEngine.__init__",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:CodeGraphEngine.scan_project",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:CodeGraphEngine.get_impact",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:CodeGraphEngine.get_ctxpack",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:get_graph_html_template",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "class:codegraph_app.py:CodeGraphRequestHandler",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:CodeGraphRequestHandler._send_json",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:CodeGraphRequestHandler._send_html",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:CodeGraphRequestHandler.do_GET",
    "value": 1
  },
  {
    "source": "function:codegraph_app.py:CodeGraphRequestHandler.do_GET",
    "target": "function:codegraph_app.py:CodeGraphRequestHandler._send_html",
    "value": 1
  },
  {
    "source": "function:codegraph_app.py:CodeGraphRequestHandler.do_GET",
    "target": "function:codegraph_app.py:get_graph_html_template",
    "value": 1
  },
  {
    "source": "function:codegraph_app.py:CodeGraphRequestHandler.do_GET",
    "target": "function:codegraph_app.py:CodeGraphRequestHandler._send_json",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:CodeGraphRequestHandler.do_POST",
    "value": 1
  },
  {
    "source": "function:codegraph_app.py:CodeGraphRequestHandler.do_POST",
    "target": "function:codegraph_app.py:CodeGraphRequestHandler._send_json",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:CodeGraphRequestHandler.log_message",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:find_free_port",
    "value": 1
  },
  {
    "source": "file:codegraph_app.py",
    "target": "function:codegraph_app.py:main",
    "value": 1
  },
  {
    "source": "function:codegraph_app.py:main",
    "target": "class:codegraph_app.py:CodeGraphEngine",
    "value": 1
  },
  {
    "source": "function:codegraph_app.py:main",
    "target": "function:codegraph_app.py:CodeGraphEngine.scan_project",
    "value": 1
  },
  {
    "source": "function:codegraph_app.py:main",
    "target": "function:codegraph_app.py:find_free_port",
    "value": 1
  },
  {
    "source": "file:codegraph_mcp.py",
    "target": "class:codegraph_mcp.py:CodeGraphEngine",
    "value": 1
  },
  {
    "source": "file:codegraph_mcp.py",
    "target": "function:codegraph_mcp.py:CodeGraphEngine.__init__",
    "value": 1
  },
  {
    "source": "function:codegraph_mcp.py:CodeGraphEngine.__init__",
    "target": "function:codegraph_mcp.py:CodeGraphEngine.scan_project",
    "value": 1
  },
  {
    "source": "file:codegraph_mcp.py",
    "target": "function:codegraph_mcp.py:CodeGraphEngine.scan_project",
    "value": 1
  },
  {
    "source": "file:codegraph_mcp.py",
    "target": "function:codegraph_mcp.py:CodeGraphEngine.get_impact",
    "value": 1
  },
  {
    "source": "file:codegraph_mcp.py",
    "target": "function:codegraph_mcp.py:CodeGraphEngine.get_ctxpack",
    "value": 1
  },
  {
    "source": "file:codegraph_mcp.py",
    "target": "function:codegraph_mcp.py:get_engine",
    "value": 1
  },
  {
    "source": "function:codegraph_mcp.py:get_engine",
    "target": "class:codegraph_mcp.py:CodeGraphEngine",
    "value": 1
  },
  {
    "source": "file:codegraph_mcp.py",
    "target": "function:codegraph_mcp.py:get_graph_stats",
    "value": 1
  },
  {
    "source": "function:codegraph_mcp.py:get_graph_stats",
    "target": "function:codegraph_mcp.py:get_engine",
    "value": 1
  },
  {
    "source": "file:codegraph_mcp.py",
    "target": "function:codegraph_mcp.py:get_code_graph",
    "value": 1
  },
  {
    "source": "function:codegraph_mcp.py:get_code_graph",
    "target": "function:codegraph_mcp.py:get_engine",
    "value": 1
  },
  {
    "source": "file:codegraph_mcp.py",
    "target": "function:codegraph_mcp.py:analyze_impact",
    "value": 1
  },
  {
    "source": "function:codegraph_mcp.py:analyze_impact",
    "target": "function:codegraph_mcp.py:get_engine",
    "value": 1
  },
  {
    "source": "file:codegraph_mcp.py",
    "target": "function:codegraph_mcp.py:pack_context",
    "value": 1
  },
  {
    "source": "function:codegraph_mcp.py:pack_context",
    "target": "function:codegraph_mcp.py:get_engine",
    "value": 1
  },
  {
    "source": "file:gen_def_summaries.py",
    "target": "function:gen_def_summaries.py:load_defs",
    "value": 1
  },
  {
    "source": "file:gen_def_summaries.py",
    "target": "function:gen_def_summaries.py:source_index",
    "value": 1
  },
  {
    "source": "file:gen_def_summaries.py",
    "target": "function:gen_def_summaries.py:add",
    "value": 1
  },
  {
    "source": "function:gen_def_summaries.py:source_index",
    "target": "function:gen_def_summaries.py:add",
    "value": 1
  },
  {
    "source": "file:gen_def_summaries.py",
    "target": "function:gen_def_summaries.py:build_prompt",
    "value": 1
  },
  {
    "source": "file:gen_def_summaries.py",
    "target": "function:gen_def_summaries.py:parse_reply",
    "value": 1
  },
  {
    "source": "file:gen_def_summaries.py",
    "target": "function:gen_def_summaries.py:save",
    "value": 1
  },
  {
    "source": "file:gen_def_summaries.py",
    "target": "function:gen_def_summaries.py:main",
    "value": 1
  },
  {
    "source": "function:gen_def_summaries.py:main",
    "target": "function:gen_def_summaries.py:load_defs",
    "value": 1
  },
  {
    "source": "function:gen_def_summaries.py:main",
    "target": "function:gen_def_summaries.py:source_index",
    "value": 1
  },
  {
    "source": "function:gen_def_summaries.py:main",
    "target": "function:gen_def_summaries.py:build_prompt",
    "value": 1
  },
  {
    "source": "function:gen_def_summaries.py:main",
    "target": "function:gen_def_summaries.py:parse_reply",
    "value": 1
  },
  {
    "source": "function:gen_def_summaries.py:main",
    "target": "function:gen_def_summaries.py:save",
    "value": 1
  },
  {
    "source": "file:gen_node_summaries.py",
    "target": "function:gen_node_summaries.py:load_targets",
    "value": 1
  },
  {
    "source": "file:gen_node_summaries.py",
    "target": "function:gen_node_summaries.py:build_prompt",
    "value": 1
  },
  {
    "source": "file:gen_node_summaries.py",
    "target": "function:gen_node_summaries.py:parse_reply",
    "value": 1
  },
  {
    "source": "file:gen_node_summaries.py",
    "target": "function:gen_node_summaries.py:save",
    "value": 1
  },
  {
    "source": "file:gen_node_summaries.py",
    "target": "function:gen_node_summaries.py:main",
    "value": 1
  },
  {
    "source": "function:gen_node_summaries.py:main",
    "target": "function:gen_node_summaries.py:load_targets",
    "value": 1
  },
  {
    "source": "function:gen_node_summaries.py:main",
    "target": "function:gen_node_summaries.py:build_prompt",
    "value": 1
  },
  {
    "source": "function:gen_node_summaries.py:main",
    "target": "function:gen_node_summaries.py:parse_reply",
    "value": 1
  },
  {
    "source": "function:gen_node_summaries.py:main",
    "target": "function:gen_node_summaries.py:save",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "class:.build_venv/Scripts/pywin32_postinstall.py:Tee",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:Tee.__init__",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:write",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:flush",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:get_root_hkey",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:create_shortcut",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:get_special_folder_path",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:CopyTo",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:LoadSystemModule",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:SetPyKeyVal",
    "value": 1
  },
  {
    "source": "function:.build_venv/Scripts/pywin32_postinstall.py:SetPyKeyVal",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:get_root_hkey",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:UnsetPyKeyVal",
    "value": 1
  },
  {
    "source": "function:.build_venv/Scripts/pywin32_postinstall.py:UnsetPyKeyVal",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:get_root_hkey",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterCOMObjects",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterHelpFile",
    "value": 1
  },
  {
    "source": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterHelpFile",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:SetPyKeyVal",
    "value": 1
  },
  {
    "source": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterHelpFile",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:UnsetPyKeyVal",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:RegisterPythonwin",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:get_shortcuts_folder",
    "value": 1
  },
  {
    "source": "function:.build_venv/Scripts/pywin32_postinstall.py:get_shortcuts_folder",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:get_root_hkey",
    "value": 1
  },
  {
    "source": "function:.build_venv/Scripts/pywin32_postinstall.py:get_shortcuts_folder",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:get_special_folder_path",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:get_system_dir",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:fixup_dbi",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:install",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:uninstall",
    "value": 1
  },
  {
    "source": "function:.build_venv/Scripts/pywin32_postinstall.py:uninstall",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:LoadSystemModule",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:verify_destination",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_postinstall.py",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:main",
    "value": 1
  },
  {
    "source": "function:.build_venv/Scripts/pywin32_postinstall.py:main",
    "target": "function:.build_venv/Scripts/pywin32_postinstall.py:verify_destination",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_testall.py",
    "target": "function:.build_venv/Scripts/pywin32_testall.py:run_test",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_testall.py",
    "target": "function:.build_venv/Scripts/pywin32_testall.py:find_and_run",
    "value": 1
  },
  {
    "source": "function:.build_venv/Scripts/pywin32_testall.py:find_and_run",
    "target": "function:.build_venv/Scripts/pywin32_testall.py:run_test",
    "value": 1
  },
  {
    "source": "file:.build_venv/Scripts/pywin32_testall.py",
    "target": "function:.build_venv/Scripts/pywin32_testall.py:main",
    "value": 1
  },
  {
    "source": "file:extensions/dynamic_call_scanner.py",
    "target": "class:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor",
    "value": 1
  },
  {
    "source": "file:extensions/dynamic_call_scanner.py",
    "target": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.__init__",
    "value": 1
  },
  {
    "source": "file:extensions/dynamic_call_scanner.py",
    "target": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_FunctionDef",
    "value": 1
  },
  {
    "source": "file:extensions/dynamic_call_scanner.py",
    "target": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_Assign",
    "value": 1
  },
  {
    "source": "file:extensions/dynamic_call_scanner.py",
    "target": "function:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor.visit_Name",
    "value": 1
  },
  {
    "source": "file:extensions/dynamic_call_scanner.py",
    "target": "function:extensions/dynamic_call_scanner.py:run_dynamic_scan",
    "value": 1
  },
  {
    "source": "function:extensions/dynamic_call_scanner.py:run_dynamic_scan",
    "target": "class:extensions/dynamic_call_scanner.py:UnappliedSymbolVisitor",
    "value": 1
  },
  {
    "source": "file:extensions/treesitter_parser.py",
    "target": "function:extensions/treesitter_parser.py:get_parser_for_lang",
    "value": 1
  },
  {
    "source": "file:extensions/treesitter_parser.py",
    "target": "function:extensions/treesitter_parser.py:scan_multilang_files",
    "value": 1
  },
  {
    "source": "function:extensions/treesitter_parser.py:scan_multilang_files",
    "target": "function:extensions/treesitter_parser.py:get_parser_for_lang",
    "value": 1
  },
  {
    "source": "file:extensions/treesitter_parser.py",
    "target": "function:extensions/treesitter_parser.py:traverse",
    "value": 1
  },
  {
    "source": "function:extensions/treesitter_parser.py:traverse",
    "target": "function:extensions/treesitter_parser.py:traverse",
    "value": 1
  },
  {
    "source": "function:extensions/treesitter_parser.py:scan_multilang_files",
    "target": "function:extensions/treesitter_parser.py:traverse",
    "value": 1
  },
  {
    "source": "file:extensions/visualize_graph.py",
    "target": "function:extensions/visualize_graph.py:log",
    "value": 1
  },
  {
    "source": "file:extensions/visualize_graph.py",
    "target": "function:extensions/visualize_graph.py:load_json",
    "value": 1
  },
  {
    "source": "function:extensions/visualize_graph.py:load_json",
    "target": "function:extensions/visualize_graph.py:log",
    "value": 1
  },
  {
    "source": "file:extensions/visualize_graph.py",
    "target": "function:extensions/visualize_graph.py:extract_community_name",
    "value": 1
  },
  {
    "source": "file:extensions/visualize_graph.py",
    "target": "function:extensions/visualize_graph.py:generate_visualization",
    "value": 1
  },
  {
    "source": "function:extensions/visualize_graph.py:generate_visualization",
    "target": "function:extensions/visualize_graph.py:log",
    "value": 1
  },
  {
    "source": "function:extensions/visualize_graph.py:generate_visualization",
    "target": "function:extensions/visualize_graph.py:load_json",
    "value": 1
  },
  {
    "source": "function:extensions/visualize_graph.py:generate_visualization",
    "target": "function:extensions/visualize_graph.py:extract_community_name",
    "value": 1
  }
]
};
