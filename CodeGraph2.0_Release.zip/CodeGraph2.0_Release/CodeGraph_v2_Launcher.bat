@echo off
title CodeGraph v2.0 Orchestrator Launcher
cd /d "%~dp0"
echo ==================================================
echo   CODEGRAPH v2.0 - TOKENVECTOR ORCHESTRATOR
echo ==================================================
echo.
2.code\tools\pytok.exe 2.code\codegraph_v2.exe run.log --name CodeGraph --path .
echo.
echo ==================================================
echo Đã hoàn tất! Mở file 1.UI\GraphView\graph_visualization.html để xem đồ thị.
echo ==================================================
pause
